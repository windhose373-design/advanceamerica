<?php
return [
    'admin_user' => 'admin',
    'admin_pass' => 'secure123',
    'encryption_key' => 'fDc4U42aLjayg_6FBZPTQDv2FG3QP8Ly-0ZXZXvDAMM=',
    'smtp' => [
        'host' => 'smtp.hostinger.com',
        'port' => 465,
        'username' => 'thankyou@advanceamerica.sbs',
        'password' => 'Good0055@@',
        'secure' => 'ssl',
        'from_email' => 'thankyou@advanceamerica.sbs',
        'from_name' => 'Advance America Form'
    ]
];
?>
